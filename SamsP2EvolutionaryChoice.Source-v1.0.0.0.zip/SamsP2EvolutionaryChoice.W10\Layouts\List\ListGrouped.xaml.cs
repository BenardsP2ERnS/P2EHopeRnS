using System.Collections.ObjectModel;
using Windows.UI.Xaml;
using AppStudio.Uwp.Controls;
using SamsP2EvolutionaryChoice.ViewModels;

namespace SamsP2EvolutionaryChoice.Layouts.List
{
    public sealed partial class ListGrouped : ListLayoutBase
    {
        public ListGrouped()
        {
            this.InitializeComponent();
        }
    }
}
