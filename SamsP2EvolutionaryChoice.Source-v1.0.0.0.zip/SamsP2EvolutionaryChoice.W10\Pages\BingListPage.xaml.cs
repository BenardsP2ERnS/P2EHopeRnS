//---------------------------------------------------------------------------
//
// <copyright file="BingListPage.xaml.cs" company="Microsoft">
//    Copyright (C) 2015 by Microsoft Corporation.  All rights reserved.
// </copyright>
//
// <createdOn>1/15/2017 4:56:33 PM</createdOn>
//
//---------------------------------------------------------------------------

using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml;
using AppStudio.DataProviders.Bing;
using SamsP2EvolutionaryChoice.Sections;
using SamsP2EvolutionaryChoice.ViewModels;
using AppStudio.Uwp;

namespace SamsP2EvolutionaryChoice.Pages
{
    public sealed partial class BingListPage : Page
    {
	    public ListViewModel ViewModel { get; set; }
        public BingListPage()
        {
			ViewModel = ViewModelFactory.NewList(new BingSection());

            this.InitializeComponent();
			commandBar.DataContext = ViewModel;
			NavigationCacheMode = NavigationCacheMode.Enabled;
            Microsoft.HockeyApp.HockeyClient.Current.TrackEvent(this.GetType().FullName);
        }

        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
			ShellPage.Current.ShellControl.SelectItem("dac156e3-8e08-4f20-8207-9395ebf926fc");
			ShellPage.Current.ShellControl.SetCommandBar(commandBar);
			if (e.NavigationMode == NavigationMode.New)
            {			
				await this.ViewModel.LoadDataAsync();
                this.ScrollToTop();
			}			
            base.OnNavigatedTo(e);
        }

    }
}
