using AppStudio.Uwp.Controls;
using Windows.UI.Xaml.Controls;

namespace SamsP2EvolutionaryChoice.Layouts.Detail
{
    public sealed partial class MultiColumnDetailLayout : BaseDetailLayout
    {
        public MultiColumnDetailLayout()
        {
            InitializeComponent();
        }        
    }
}
