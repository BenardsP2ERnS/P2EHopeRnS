namespace SamsP2EvolutionaryChoice.Layouts.List
{
    public sealed partial class MenuBig : ListLayoutBase
    {
        public MenuBig()
        {
            this.InitializeComponent();
        }
    }
}
