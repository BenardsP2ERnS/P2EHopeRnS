namespace SamsP2EvolutionaryChoice.Layouts.List
{
    public sealed partial class CarouselBig : ListLayoutBase
    {
        public CarouselBig()
        {
            this.InitializeComponent();
        }
    }
}
