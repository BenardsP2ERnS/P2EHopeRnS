using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using System.Windows.Input;
using AppStudio.Uwp;
using AppStudio.Uwp.Actions;
using AppStudio.Uwp.Navigation;
using AppStudio.Uwp.Commands;
using AppStudio.DataProviders;

using AppStudio.DataProviders.Html;
using AppStudio.DataProviders.Menu;
using AppStudio.DataProviders.Bing;
using AppStudio.DataProviders.LocalStorage;
using SamsP2EvolutionaryChoice.Sections;


namespace SamsP2EvolutionaryChoice.ViewModels
{
    public class MainViewModel : PageViewModelBase
    {
        public ListViewModel Power2EvolutionaryChoice { get; private set; }
        public ListViewModel VariousP2EHopeRnSWebsites { get; private set; }
        public ListViewModel Bing { get; private set; }
		public AdvertisingViewModel SectionAd { get; set; }

        public MainViewModel(int visibleItems) : base()
        {
            Title = "SamsP2EvolutionaryChoice";
			this.SectionAd = new AdvertisingViewModel();
            Power2EvolutionaryChoice = ViewModelFactory.NewList(new Power2EvolutionaryChoiceSection(), visibleItems);
            VariousP2EHopeRnSWebsites = ViewModelFactory.NewList(new VariousP2EHopeRnSWebsitesSection());
            Bing = ViewModelFactory.NewList(new BingSection(), visibleItems);

            if (GetViewModels().Any(vm => !vm.HasLocalData))
            {
                Actions.Add(new ActionInfo
                {
                    Command = RefreshCommand,
                    Style = ActionKnownStyles.Refresh,
                    Name = "RefreshButton",
                    ActionType = ActionType.Primary
                });
            }
        }

		#region Commands
		public ICommand RefreshCommand
        {
            get
            {
                return new RelayCommand(async () =>
                {
                    var refreshDataTasks = GetViewModels()
                        .Where(vm => !vm.HasLocalData).Select(vm => vm.LoadDataAsync(true));

                    await Task.WhenAll(refreshDataTasks);
					LastUpdated = GetViewModels().OrderBy(vm => vm.LastUpdated, OrderType.Descending).FirstOrDefault()?.LastUpdated;
                    OnPropertyChanged("LastUpdated");
                });
            }
        }
		#endregion

        public async Task LoadDataAsync()
        {
            var loadDataTasks = GetViewModels().Select(vm => vm.LoadDataAsync());

            await Task.WhenAll(loadDataTasks);
			LastUpdated = GetViewModels().OrderBy(vm => vm.LastUpdated, OrderType.Descending).FirstOrDefault()?.LastUpdated;
            OnPropertyChanged("LastUpdated");
        }

        private IEnumerable<ListViewModel> GetViewModels()
        {
            yield return Power2EvolutionaryChoice;
            yield return VariousP2EHopeRnSWebsites;
            yield return Bing;
        }
    }
}
