using System;
using AppStudio.Uwp;

namespace SamsP2EvolutionaryChoice.ViewModels
{
    public class PrivacyViewModel : ObservableBase
    {
        public Uri Url
        {
            get
            {
                return new Uri(UrlText, UriKind.RelativeOrAbsolute);
            }
        }
        public string UrlText
        {
            get
            {
                return "https://social.msdn.microsoft.com/search/en-US/windows?query=privacy%20policy%20p3p&refinement=183";
            }
        }
    }
}

