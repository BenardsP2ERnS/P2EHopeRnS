namespace SamsP2EvolutionaryChoice.Layouts.List
{
    public sealed partial class ListContactCard : ListLayoutBase
    {
        public ListContactCard()
        {
            this.InitializeComponent();
        }
    }
}
