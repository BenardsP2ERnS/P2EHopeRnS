namespace SamsP2EvolutionaryChoice.Layouts.List
{
    public sealed partial class ListPhoto : ListLayoutBase
    {
        public ListPhoto() : base()
        {
            this.InitializeComponent();
        }
    }
}
