namespace SamsP2EvolutionaryChoice.Layouts.List
{
    public sealed partial class ListBigHorizontalCardBox : ListLayoutBase
    {
        public ListBigHorizontalCardBox()
        {
            this.InitializeComponent();
        }
    }
}
