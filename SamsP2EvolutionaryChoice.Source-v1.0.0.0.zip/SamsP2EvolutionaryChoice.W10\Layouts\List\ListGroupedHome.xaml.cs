using AppStudio.Uwp.Controls;
using Windows.UI.Xaml;

namespace SamsP2EvolutionaryChoice.Layouts.List
{
    public sealed partial class ListGroupedHome : ListLayoutBase
    {
        public ListGroupedHome()
        {
            this.InitializeComponent();
        }
    }
}
