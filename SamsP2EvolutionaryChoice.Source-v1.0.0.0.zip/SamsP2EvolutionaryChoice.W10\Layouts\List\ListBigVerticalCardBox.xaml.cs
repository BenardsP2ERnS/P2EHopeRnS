namespace SamsP2EvolutionaryChoice.Layouts.List
{
    public sealed partial class ListBigVerticalCardBox : ListLayoutBase
    {
        public ListBigVerticalCardBox()
        {
            this.InitializeComponent();
        }
    }
}
