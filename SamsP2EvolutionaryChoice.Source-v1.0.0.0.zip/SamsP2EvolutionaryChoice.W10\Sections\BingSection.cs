using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using AppStudio.DataProviders;
using AppStudio.DataProviders.Core;
using AppStudio.DataProviders.Bing;
using AppStudio.Uwp.Actions;
using AppStudio.Uwp.Commands;
using AppStudio.Uwp;
using System.Linq;

using SamsP2EvolutionaryChoice.Navigation;
using SamsP2EvolutionaryChoice.ViewModels;

namespace SamsP2EvolutionaryChoice.Sections
{
	public class BingSection : Section<BingSchema>
    {
		private BingDataProvider _dataProvider;		

		public BingSection()
		{
			_dataProvider = new BingDataProvider();
		}

		public override async Task<IEnumerable<BingSchema>> GetDataAsync(SchemaBase connectedItem = null)
        {
            var config = new BingDataConfig
            {
                Country = BingCountry.UnitedStates,
                Query = @"Windows App Studio"
            };
            return await _dataProvider.LoadDataAsync(config, MaxRecords);
        }

        public override async Task<IEnumerable<BingSchema>> GetNextPageAsync()
        {
            return await _dataProvider.LoadMoreDataAsync();
        }

        public override bool HasMorePages
        {
            get
            {
                return _dataProvider.HasMoreItems;
            }
        }

        public override ListPageConfig<BingSchema> ListPage
        {
            get 
            {
                return new ListPageConfig<BingSchema>
                {
                    Title = "Bing",

					Page = typeof(Pages.BingListPage),

                    LayoutBindings = (viewModel, item) =>
                    {
                        viewModel.Title = item.Title.ToSafeString();
                        viewModel.SubTitle = item.Summary.ToSafeString();
                    },
                    DetailNavigation = (item) =>
                    {
                        return new NavInfo
                        {
                            NavigationType = NavType.DeepLink,
                            TargetUri = new Uri(item.Link)
                        };
                    }
                };
            }
        }

        public override DetailPageConfig<BingSchema> DetailPage
        {
            get { return null; }
        }
    }
}
