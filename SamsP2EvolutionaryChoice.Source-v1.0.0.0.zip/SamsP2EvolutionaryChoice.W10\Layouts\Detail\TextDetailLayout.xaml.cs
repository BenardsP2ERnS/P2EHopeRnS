namespace SamsP2EvolutionaryChoice.Layouts.Detail
{
    public sealed partial class TextDetailLayout : BaseDetailLayout
    {
        public TextDetailLayout()
        {
            InitializeComponent();
        }
    }
}
